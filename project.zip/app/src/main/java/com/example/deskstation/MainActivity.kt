package com.example.deskstation

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.PlaybackState
import android.media.session.MediaSessionManager
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val sessions by lazy { getSystemService(MEDIA_SESSION_SERVICE) as MediaSessionManager }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(), "DeskBridge")
        web.loadUrl("file:///android_asset/dashboard.html")
    }

    private fun activeController(): MediaController? = try {
        val listener = ComponentName(this, MediaListenerService::class.java)
        val active = sessions.getActiveSessions(listener)
        active.firstOrNull { it.packageName.contains("spotify", true) ||
            it.packageName.contains("youtube", true) } ?: active.firstOrNull()
    } catch (_: Exception) { null }

    inner class Bridge {
        @JavascriptInterface fun getCurrentTrackJson(): String {
            val c = activeController() ?: return JSONObject().put("title", "").toString()
            val md = c.metadata
            val state = c.playbackState
            val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: ""
            val artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST)
                ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: ""
            val duration = md?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
            val artwork = md?.getBitmap(MediaMetadata.METADATA_KEY_ART) 
                ?: md?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            val artworkData = try {
                if (artwork != null) {
                    val scaled = if (artwork.width > 512 || artwork.height > 512) {
                        val scale = minOf(512f / artwork.width, 512f / artwork.height)
                        android.graphics.Bitmap.createScaledBitmap(
                            artwork, (artwork.width * scale).toInt().coerceAtLeast(1),
                            (artwork.height * scale).toInt().coerceAtLeast(1), true
                        )
                    } else artwork
                    val output = java.io.ByteArrayOutputStream()
                    scaled.compress(android.graphics.Bitmap.CompressFormat.JPEG, 82, output)
                    "data:image/jpeg;base64," + Base64.encodeToString(output.toByteArray(), Base64.NO_WRAP)
                } else ""
            } catch (_: Exception) { "" }
            val json = JSONObject().put("title", title).put("artist", artist)
                .put("artworkUrl", artworkData)
                .put("app", when {
                    c.packageName.contains("spotify", true) -> "Spotify"
                    c.packageName.contains("youtube", true) && c.packageName.contains("music", true) -> "YouTube Music"
                    c.packageName.contains("youtube", true) -> "YouTube"
                    else -> c.packageName
                })
                .put("playing", state?.state == PlaybackState.STATE_PLAYING)
                .put("positionMs", state?.position ?: 0L).put("durationMs", duration)
            return json.toString()
        }

        @JavascriptInterface fun control(action: String) {
            runOnUiThread {
                val c = activeController() ?: return@runOnUiThread
                when (action) {
                    "toggle" -> if (c.playbackState?.state == PlaybackState.STATE_PLAYING)
                        c.transportControls.pause() else c.transportControls.play()
                    "next" -> c.transportControls.skipToNext()
                    "previous" -> c.transportControls.skipToPrevious()
                }
            }
        }

        @JavascriptInterface fun openApp(name: String) {
            runOnUiThread {
                val pkg = when (name) {
                    "spotify" -> "com.spotify.music"
                    "youtube_music" -> "com.google.android.apps.youtube.music"
                    else -> "com.google.android.youtube"
                }
                val launch = packageManager.getLaunchIntentForPackage(pkg)
                if (launch != null) startActivity(launch) else {
                    val url = when (name) {
                        "spotify" -> "https://open.spotify.com/"
                        "youtube_music" -> "https://music.youtube.com/"
                        else -> "https://m.youtube.com/"
                    }
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                }
            }
        }

        @JavascriptInterface fun openNotificationAccess() {
            runOnUiThread { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        }
    }
}
